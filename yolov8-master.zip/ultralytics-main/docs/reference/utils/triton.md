# Reference for `ultralytics/utils/triton.py`

!!! note

    Full source code for this file is available at [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/triton.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/triton.py). Help us fix any issues you see by submitting a [Pull Request](https://docs.ultralytics.com/help/contributing/) 🛠️. Thank you 🙏!

---
## ::: ultralytics.utils.triton.TritonRemoteModel
<br><br>
